<?php
/**
 * @package Hello
 */
/*
Plugin Name: Hello
Plugin URI: http://hello.com/
Description: Plugin Hello aksioma.
Version: 1.0
Author: Automattic
Author URI: http://disitus.com/plugins/
License: GPLv2 or later
Text Domain: ekonomisyariah.net
*/


